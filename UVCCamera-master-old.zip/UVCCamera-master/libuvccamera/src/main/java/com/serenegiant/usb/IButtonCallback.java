package com.serenegiant.usb;

public interface IButtonCallback {
    void onButton(int button, int state);
}
